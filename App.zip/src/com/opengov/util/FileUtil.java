package com.opengov.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;



public class FileUtil {

//FileUtil is a singleton Implementation	
	private static FileUtil fileUtil;
	private FileUtil(){System.out.println("FileUtil is instantiated");};
	
	public static FileUtil getInstance(){
		if (fileUtil==null){
			fileUtil=new FileUtil();
		}
		return fileUtil;
	}
	
	public boolean checkIfFileDirExists (String filePath) {
		Path paths = Paths.get(filePath);
		boolean pathExists=Files.exists(paths, new LinkOption[]{ LinkOption.NOFOLLOW_LINKS});
		return pathExists;
	}
	
	public boolean createDirectory (String dirPath) {
		Path path = Paths.get(dirPath);

		try {
		    	Files.createDirectory(path);
		} catch(FileAlreadyExistsException e){
		    System.out.println("Directory Already Exists");
		} catch (IOException e) {
		    System.out.println("Something went wrong while creating directory");
		    return false;
		    
		}
		return true;
	}
	
	public boolean createFile (String dirPath) {
		Path path = Paths.get(dirPath);

		try {
		    	Files.createFile(path);
		} catch(FileAlreadyExistsException e){
		    System.out.println("File Already Exists");
		} catch (IOException e) {
		    System.out.println("Something went wrong while creating File");
		    return false;    
		}
		return true;
	}
	

	public boolean reCreateFile (String dirPath) {
		Path path = Paths.get(dirPath);

		try {
				Files.deleteIfExists(path);
		    	Files.createFile(path);
		} catch(FileAlreadyExistsException e){
		    System.out.println("File reCreated");
		} catch (IOException e) {
		    System.out.println("Something went wrong while creating File");
		    return false;    
		}
		return true;
	}


	
	public List<String> readFilesInList (String filePath){
		List<String> lines= new ArrayList<String>();
		try {
			lines = Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);
		} catch (IOException e) {
			System.out.println("Something went wrong while reading a File");
		}
		return lines;
	}
	
	
	public boolean writeToFileusingString(String path,String inputString) {
		Path pathOfFile = Paths.get(path);
		boolean opSuccess=false;
		//for (int i=0;i<inputList.size();i++) {
			try {
				
				Files.write(pathOfFile, inputString.getBytes(),StandardOpenOption.APPEND);
				Files.write(pathOfFile, "\n".getBytes(), StandardOpenOption.APPEND);
				opSuccess=true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//}
		return opSuccess;
	}
	
	public Properties readPropertiesFile(String propertyFilePath) {
		Properties p=new Properties();
		try {
			
			FileReader reader = new FileReader(propertyFilePath);  
		    p.load(reader);
		    //System.out.println(p.getProperty("user"));  
		    //System.out.println(p.getProperty("password"));  
		} catch (FileNotFoundException e) {
			File f = new File(propertyFilePath.substring(3));
			Properties pAbs=readPropertiesFile(f.getAbsolutePath());
			return pAbs;
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
	}
	
	public boolean cleanDirectory (String dirPath){
		boolean cleanSuccess=false;
		File f = new File (dirPath);
		if (checkIfPathIsDir(dirPath)){
			for (int i=0; i<f.listFiles().length;i++){
				Path path= Paths.get(f.listFiles()[i].getAbsolutePath());
				try {
					Files.delete(path);
				} catch (IOException e) {
					System.out.println("File Delete Operation Failed for "+ f.listFiles()[i].getAbsolutePath());
					e.printStackTrace();
				}
			}	
		}
		else {
			System.out.println("Path provided is not directory");
		}
		return cleanSuccess;
	}
	
	public boolean checkIfPathIsDir (String dirPath){
		boolean isDir=false;
			File f = new File (dirPath);
			if (f.isDirectory()){	
			isDir=true;
		}
		return isDir;
	}
	
}	
