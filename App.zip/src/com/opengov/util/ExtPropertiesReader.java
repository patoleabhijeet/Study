package com.opengov.util;

import java.util.Properties;

import com.opengov.CONSTANTS.AppConstants;

public class ExtPropertiesReader {
	
	private static ExtPropertiesReader exPropReader;
	private ExtPropertiesReader(){System.out.println("External Properties reader instantiated");};
	
	public Properties getProperties (){
		FileUtil fileUtil = FileUtil.getInstance();
		Properties p=fileUtil.readPropertiesFile(AppConstants.ROOTFOLDER+AppConstants.PATHFORPROPERTIESFILE);
		return p;
		
	}
	
	public static ExtPropertiesReader getInstance()
	{
		
		if (exPropReader==null){
		 exPropReader=new ExtPropertiesReader();
		}
		return exPropReader;
	}
	
	
	//private static ExtPropertiesReader exPropReader;
	//public String dummyText;
	
//	private ExtPropertiesReader(){
//		dummyText="This is singleton Impl of external Properties reader";
//	}
	
	

}
