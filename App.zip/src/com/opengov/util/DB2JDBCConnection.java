package com.opengov.util;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.opengov.DO.DB2ParmList;

import java.sql.Connection;

public class DB2JDBCConnection {
	private static DB2JDBCConnection db2JDBCConnection;
	private DB2JDBCConnection (){System.out.println("DB2 Connection singleton is made");};
	
	public static DB2JDBCConnection getInstance(){
		if (db2JDBCConnection==null){
			db2JDBCConnection=new DB2JDBCConnection();
		}
		return db2JDBCConnection;
	}
	
	public Connection db2ConnectJDBC(DB2ParmList db2ParmList) {
		try {
			 Class.forName("com.ibm.db2.jcc.DB2Driver");
			 } catch (ClassNotFoundException e) {
			 System.out.println("Please include Classpath Where your DB2 Driver is located");
			 e.printStackTrace();
			 
			 }
			 //System.out.println("DB2 driver is loaded successfully");
			 Connection conn = null;
			 try {
				 String connString="jdbc:db2:"+db2ParmList.getDb2Alias();
				 //conn = DriverManager.getConnection("jdbc:db2:STWTPDB");
				 conn = DriverManager.getConnection(connString,db2ParmList.getuID(),db2ParmList.getPwd());
				 if (conn != null)
				 {
					 
					 //System.out.println("DB2 Database Connected");
				 }
				 else
				 {
					 System.out.println("Db2 connection Failed ");
				 }
			 	}
			 	catch (SQLException e) {
			 		System.out.println("DB2 Database connection Failed for "+db2ParmList.getDb2Alias());
			 		e.printStackTrace();
			 		
			 	}
			 return conn;	
	}
}

