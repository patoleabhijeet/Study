package com.opengov.util;

import java.util.ArrayList;
import java.util.List;

import com.opengov.DO.DB2ParmList;

public class GetDB2SchemaDtl {
	public List<DB2ParmList> getDB2SchemaDtl(){
		List<DB2ParmList> db2ParmListArray = new ArrayList<DB2ParmList>();
		ExtPropertiesReader.getInstance().getProperties().get("DB2_CLI_PATH").toString();
		//System.out.println(ExtPropertiesReader.getInstance().getProperties().get("DB2_CLI_PATH").toString());
		List<String> db2CLIContent=FileUtil.getInstance().readFilesInList(ExtPropertiesReader.getInstance().getProperties().get("DB2_CLI_PATH").toString());
		//System.out.println(db2CLIContent.size());
		String[] contentArr = new String[2];
		for (int i=0;i<db2CLIContent.size();i++){
			if (db2CLIContent.get(i).trim().startsWith("[")){
				DB2ParmList db2ParmList = new DB2ParmList();
				
				i++;
				contentArr=db2CLIContent.get(i).split("=");
				//System.out.println(contentArr[1]);
				db2ParmList.setDb2Alias(contentArr[1]);
				
				i++;
				contentArr=db2CLIContent.get(i).split("=");
				//System.out.println(contentArr[1]);
				db2ParmList.setPwd(contentArr[1]);
				
				i++;
				contentArr=db2CLIContent.get(i).split("=");
				//System.out.println(contentArr[1]);
				db2ParmList.setuID(contentArr[1]);
				
				i++;
				contentArr=db2CLIContent.get(i).split("=");
				//System.out.println(contentArr[1]);
				db2ParmList.setCurrentSchema(contentArr[1]);
				
				db2ParmListArray.add(db2ParmList);
			}
			
			
		}
		//System.out.println(db2ParmListArray.size());
		
		//for (int j=0;j<db2ParmListArray.size();j++){
		//	System.out.println(db2ParmListArray.get(j).getDb2Alias());
		//}
		return db2ParmListArray;
		
	}

}
