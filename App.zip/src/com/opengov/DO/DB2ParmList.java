package com.opengov.DO;

public class DB2ParmList {

	private String db2Alias;
	private String pwd;
	private String uID;
	private String currentSchema;
	public String getDb2Alias() {
		return db2Alias;
	}
	public void setDb2Alias(String db2Alias) {
		this.db2Alias = db2Alias;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getuID() {
		return uID;
	}
	public void setuID(String uID) {
		this.uID = uID;
	}
	public String getCurrentSchema() {
		return currentSchema;
	}
	public void setCurrentSchema(String currentSchema) {
		this.currentSchema = currentSchema;
	}
	
	
}
