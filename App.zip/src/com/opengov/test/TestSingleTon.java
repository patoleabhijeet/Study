package com.opengov.test;

import com.opengov.util.ExtPropertiesReader;
import com.opengov.util.GetDB2SchemaDtl;

public class TestSingleTon {
	public static void main(String[] args){
		
		 ExtPropertiesReader ex1 = ExtPropertiesReader.getInstance();
		 //ExtPropertiesReader ex2 = ExtPropertiesReader.getInstance();
		 //ExtPropertiesReader ex3 = ExtPropertiesReader.getInstance();
		 
		 //System.out.println(ex1);
		 //System.out.println(ex2);
		 //System.out.println(ex3);
		 System.out.println(ex1.getProperties().size());
		 GetDB2SchemaDtl g = new GetDB2SchemaDtl();
		 g.getDB2SchemaDtl();
	}
}
