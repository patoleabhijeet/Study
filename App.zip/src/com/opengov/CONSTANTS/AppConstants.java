package com.opengov.CONSTANTS;

public final class AppConstants {
	public static final String DB2_CLI_PATH="E:/stw/stw_data/stwcmd/";
	public static final String DB2_CLI_INI="db2cli.ini";
	public static final String STWTPDB ="STWTPDB";
	public static final String PATHFORPROPERTIESFILE="App.properties";
	public static final String ROOTFOLDER="./";
	
}

