package com.opengov.impl;

import com.opengov.util.ExtPropertiesReader;
import com.opengov.util.FileUtil;

public class CreateFolderAndFiles {
	public boolean checkForRootDir(){
		boolean dirFound=false;
		if (
		    FileUtil.getInstance().checkIfFileDirExists(ExtPropertiesReader.getInstance().getProperties().get("rootDir").toString())
		    ){
			dirFound=true;
		}
		return dirFound;
	}
	
	public boolean cleanRootAndSubDir(String dirPath){
		return FileUtil.getInstance().cleanDirectory(dirPath);
	}
}
